<div class="d-flex justify-content-center align-items-center">
    <span>Dashboard Test</span>
</div>